import Classes.*;

import java.lang.*;
import javax.swing.*;
public class Start
{
	public static void main(String[] args)
	{
		Login l1=new Login();
		l1.setVisible(true);
	}
}